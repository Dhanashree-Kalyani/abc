package com.example.p6final;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class thirdactivity extends AppCompatActivity {
    Switch aSwitch;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdactivity);
        aSwitch = findViewById(R.id.switch1);
        fab = findViewById(R.id.fab);
        //Button button=(Button)findViewById(R.id.button3);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(thirdactivity.this,fourthactivity.class);
                startActivity(intent);

            }
        });
        /*button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(thirdactivity.this,fourthactivity.class);
                startActivity(intent);
            }
        });*/
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

                }
                else
                {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
            }
        });


    }

    public static class CourseModel {

        private String course_name;
        private int course_rating;
        private int course_image;

        // Constructor
        public CourseModel(String course_name, int course_rating, int course_image) {
            this.course_name = course_name;
            this.course_rating = course_rating;
            this.course_image = course_image;
        }

        // Getter and Setter
        public String getCourse_name() {
            return course_name;
        }

        public void setCourse_name(String course_name) {
            this.course_name = course_name;
        }

        public int getCourse_rating() {
            return course_rating;
        }

        public void setCourse_rating(int course_rating) {
            this.course_rating = course_rating;
        }

        public int getCourse_image() {
            return course_image;
        }

        public void setCourse_image(int course_image) {
            this.course_image = course_image;
        }
    }
}